
'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface EmergencyContact {
  name: string;
  phone: string;
  type: string;
}

export default function SOSPage() {
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [isEmergency, setIsEmergency] = useState(false);
  const [emergencyType, setEmergencyType] = useState('');
  const [emergencyMessage, setEmergencyMessage] = useState('');
  const [userInfo, setUserInfo] = useState({
    name: '',
    phone: '',
    medical: ''
  });

  const emergencyContacts: EmergencyContact[] = [
    { name: 'Cảnh sát', phone: '113', type: 'police' },
    { name: 'Cứu hỏa', phone: '114', type: 'fire' },
    { name: 'Cấp cứu y tế', phone: '115', type: 'medical' },
    { name: 'Cứu hộ giao thông', phone: '1900 1560', type: 'traffic' },
    { name: 'Điện lực', phone: '19001909', type: 'electric' },
    { name: 'Nước sạch', phone: '19006268', type: 'water' }
  ];

  const emergencyTypes = [
    'Tai nạn giao thông',
    'Hỏa hoạn',
    'Lũ lụt',
    'Sạt lở đất',
    'Bão to',
    'Y tế khẩn cấp',
    'Mất tích',
    'Khác'
  ];

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  }, []);

  const handleEmergencyCall = (phone: string) => {
    window.open(`tel:${phone}`);
  };

  const handleSendSOS = () => {
    if (!emergencyType || !userInfo.name || !userInfo.phone) {
      alert('Vui lòng điền đầy đủ thông tin!');
      return;
    }

    const sosData = {
      type: emergencyType,
      message: emergencyMessage,
      location: location,
      userInfo: userInfo,
      timestamp: new Date().toISOString()
    };

    console.log('SOS Data:', sosData);
    
    setIsEmergency(true);
    
    setTimeout(() => {
      alert('Tín hiệu SOS đã được gửi thành công! Đội cứu hộ sẽ liên hệ với bạn sớm nhất.');
      setIsEmergency(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-red-600 mb-4">
              <i className="ri-alarm-warning-line mr-2"></i>
              Hệ thống cứu hộ SOS
            </h1>
            <p className="text-lg text-gray-600">
              Trong trường hợp khẩn cấp, hãy sử dụng các tính năng dưới đây để được hỗ trợ nhanh nhất
            </p>
          </div>

          {/* Emergency Contacts */}
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Số điện thoại khẩn cấp</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {emergencyContacts.map((contact, index) => (
                <button
                  key={index}
                  onClick={() => handleEmergencyCall(contact.phone)}
                  className="flex items-center p-4 bg-red-50 hover:bg-red-100 rounded-lg border border-red-200 transition-colors cursor-pointer"
                >
                  <div className="w-12 h-12 flex items-center justify-center bg-red-600 text-white rounded-full mr-4">
                    <i className={`ri-phone-line text-xl`}></i>
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-gray-800">{contact.name}</div>
                    <div className="text-red-600 font-bold text-lg">{contact.phone}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* SOS Form */}
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Gửi tín hiệu SOS</h2>
            
            <form id="sos-form" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Họ và tên *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={userInfo.name}
                    onChange={(e) => setUserInfo({...userInfo, name: e.target.value})}
                    className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Nhập họ tên của bạn"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Số điện thoại *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={userInfo.phone}
                    onChange={(e) => setUserInfo({...userInfo, phone: e.target.value})}
                    className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="Nhập số điện thoại"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Loại tình huống khẩn cấp *
                </label>
                <select
                  name="emergencyType"
                  value={emergencyType}
                  onChange={(e) => setEmergencyType(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500 pr-8"
                  required
                >
                  <option value="">Chọn loại tình huống</option>
                  {emergencyTypes.map((type, index) => (
                    <option key={index} value={type}>{type}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Thông tin y tế (nếu có)
                </label>
                <input
                  type="text"
                  name="medical"
                  value={userInfo.medical}
                  onChange={(e) => setUserInfo({...userInfo, medical: e.target.value})}
                  className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Bệnh lý, dị ứng, thuốc đang dùng..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mô tả tình huống
                </label>
                <textarea
                  name="message"
                  value={emergencyMessage}
                  onChange={(e) => setEmergencyMessage(e.target.value)}
                  rows={4}
                  maxLength={500}
                  className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="Mô tả chi tiết tình huống hiện tại..."
                />
                <div className="text-sm text-gray-500 mt-1">
                  {emergencyMessage.length}/500 ký tự
                </div>
              </div>

              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  <i className="ri-map-pin-line text-blue-600 mr-2"></i>
                  <span className="font-medium text-blue-800">Vị trí hiện tại</span>
                </div>
                {location ? (
                  <p className="text-blue-700">
                    Đã xác định vị trí: {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                  </p>
                ) : (
                  <p className="text-blue-700">Đang xác định vị trí...</p>
                )}
              </div>

              <button
                type="button"
                onClick={handleSendSOS}
                disabled={isEmergency}
                className={`w-full py-4 px-6 rounded-lg text-white font-bold text-lg transition-colors whitespace-nowrap ${
                  isEmergency 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-red-600 hover:bg-red-700 cursor-pointer'
                }`}
              >
                {isEmergency ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Đang gửi SOS...
                  </>
                ) : (
                  <>
                    <i className="ri-alarm-warning-line mr-2"></i>
                    GỬI TÍN HIỆU SOS
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Safety Tips */}
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-2xl font-semibold text-gray-800 mb-6">Hướng dẫn an toàn</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-green-600 mb-3">
                  <i className="ri-shield-check-line mr-2"></i>
                  Trước khi gặp khẩn cấp
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Lưu các số điện thoại khẩn cấp</li>
                  <li>• Chuẩn bị túi cứu thương cơ bản</li>
                  <li>• Biết đường thoát hiểm tại nhà/công việc</li>
                  <li>• Thông báo kế hoạch với gia đình</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-orange-600 mb-3">
                  <i className="ri-alert-line mr-2"></i>
                  Khi gặp tình huống khẩn cấp
                </h3>
                <ul className="space-y-2 text-gray-700">
                  <li>• Giữ bình tĩnh và đánh giá tình huống</li>
                  <li>• Gọi ngay số khẩn cấp phù hợp</li>
                  <li>• Cung cấp thông tin chính xác</li>
                  <li>• Thực hiện sơ cứu nếu có thể</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
