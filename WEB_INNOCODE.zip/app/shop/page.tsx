
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  image: string;
  description: string;
  rating: number;
  reviews: number;
  inStock: boolean;
  isAffiliate?: boolean;
}

export default function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  const categories = [
    { value: 'all', label: 'Tất cả sản phẩm', count: 24 },
    { value: 'seeds', label: 'Cây giống', count: 12 },
    { value: 'rescue', label: 'Đồ cứu hộ', count: 8 },
    { value: 'tools', label: 'Dụng cụ nông nghiệp', count: 4 }
  ];

  const products: Product[] = [
    {
      id: '1',
      name: 'Giống lúa ST25 cao cấp',
      category: 'seeds',
      price: 125000,
      originalPrice: 150000,
      image: 'https://readdy.ai/api/search-image?query=Premium%20ST25%20rice%20seeds%20in%20professional%20packaging%20bags%2C%20high%20quality%20Vietnamese%20rice%20variety%20seeds%20for%20planting%2C%20agricultural%20seed%20products%20with%20clear%20labeling&width=300&height=300&seq=seed1&orientation=squarish',
      description: 'Giống lúa ST25 đạt giải thưởng thế giới, năng suất cao, chất lượng gạo thơm ngon',
      rating: 4.8,
      reviews: 156,
      inStock: true
    },
    {
      id: '2',
      name: 'Bộ cứu hộ lũ lụt gia đình',
      category: 'rescue',
      price: 890000,
      image: 'https://readdy.ai/api/search-image?query=Emergency%20flood%20rescue%20kit%20for%20family%2C%20waterproof%20emergency%20bag%20with%20life%20vest%2C%20flashlight%2C%20first%20aid%20supplies%2C%20rope%20and%20emergency%20tools%2C%20complete%20disaster%20preparedness%20kit&width=300&height=300&seq=rescue1&orientation=squarish',
      description: 'Bộ dụng cụ cứu hộ đầy đủ cho gia đình khi gặp lũ lụt: áo phao, đèn pin, dây thừng',
      rating: 4.9,
      reviews: 89,
      inStock: true,
      isAffiliate: true
    },
    {
      id: '3',
      name: 'Giống cà chua bi F1',
      category: 'seeds',
      price: 45000,
      image: 'https://readdy.ai/api/search-image?query=Cherry%20tomato%20F1%20hybrid%20seeds%20in%20small%20packets%2C%20premium%20vegetable%20seeds%20for%20home%20gardening%2C%20colorful%20seed%20packaging%20with%20tomato%20images&width=300&height=300&seq=seed2&orientation=squarish',
      description: 'Giống cà chua bi F1 chất lượng cao, ra quả nhiều, thích hợp trồng sân vườn',
      rating: 4.7,
      reviews: 234,
      inStock: true
    },
    {
      id: '4',
      name: 'Máy bơm nước mini di động',
      category: 'rescue',
      price: 1250000,
      originalPrice: 1500000,
      image: 'https://readdy.ai/api/search-image?query=Portable%20mini%20water%20pump%20for%20emergency%20flood%20situations%2C%20compact%20electric%20water%20pump%20with%20hose%2C%20emergency%20drainage%20equipment%20for%20home%20use&width=300&height=300&seq=pump1&orientation=squarish',
      description: 'Máy bơm nước di động nhỏ gọn, hữu ích khi nhà bị ngập nước',
      rating: 4.6,
      reviews: 67,
      inStock: true
    },
    {
      id: '5',
      name: 'Giống rau muống lá to',
      category: 'seeds',
      price: 25000,
      image: 'https://readdy.ai/api/search-image?query=Water%20spinach%20seeds%20with%20large%20leaves%20variety%2C%20Vietnamese%20vegetable%20seeds%20in%20clear%20packaging%2C%20traditional%20leafy%20green%20vegetable%20seeds%20for%20cultivation&width=300&height=300&seq=seed3&orientation=squarish',
      description: 'Giống rau muống lá to, sinh trưởng nhanh, phù hợp vùng ẩm ướt',
      rating: 4.5,
      reviews: 178,
      inStock: true
    },
    {
      id: '6',
      name: 'Bộ dụng cụ làm vườn cơ bản',
      category: 'tools',
      price: 320000,
      image: 'https://readdy.ai/api/search-image?query=Basic%20gardening%20tool%20set%20with%20small%20shovel%2C%20rake%2C%20pruning%20shears%2C%20watering%20can%2C%20gloves%20in%20organized%20tool%20box%20for%20home%20farming%20and%20gardening&width=300&height=300&seq=tools1&orientation=squarish',
      description: 'Bộ dụng cụ làm vườn gồm: cuốc, cào, kéo cắt cành, bình tưới nước',
      rating: 4.4,
      reviews: 95,
      inStock: true
    },
    {
      id: '7',
      name: 'Đèn pin sạc năng lượng mặt trời',
      category: 'rescue',
      price: 180000,
      image: 'https://readdy.ai/api/search-image?query=Solar%20powered%20rechargeable%20flashlight%20for%20emergency%20use%2C%20waterproof%20LED%20flashlight%20with%20solar%20panel%2C%20emergency%20lighting%20equipment%20for%20disaster%20situations&width=300&height=300&seq=light1&orientation=squarish',
      description: 'Đèn pin sạc năng lượng mặt trời, chống nước, pin bền lâu',
      rating: 4.7,
      reviews: 142,
      inStock: true,
      isAffiliate: true
    },
    {
      id: '8',
      name: 'Giống cà phê Robusta chất lượng cao',
      category: 'seeds',
      price: 85000,
      image: 'https://readdy.ai/api/search-image?query=Premium%20Robusta%20coffee%20seedlings%20in%20small%20pots%2C%20young%20coffee%20plants%20ready%20for%20planting%2C%20Vietnamese%20coffee%20cultivation%2C%20highland%20coffee%20farming&width=300&height=300&seq=coffee1&orientation=squarish',
      description: 'Cây giống cà phê Robusta chất lượng cao từ Tây Nguyên',
      rating: 4.8,
      reviews: 203,
      inStock: false
    }
  ];

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    
    let matchesPrice = true;
    if (priceRange === 'under-100k') matchesPrice = product.price < 100000;
    else if (priceRange === '100k-500k') matchesPrice = product.price >= 100000 && product.price <= 500000;
    else if (priceRange === 'over-500k') matchesPrice = product.price > 500000;
    
    return matchesCategory && matchesPrice;
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-1/4">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-24">
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Bộ lọc</h2>
              
              {/* Categories */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-3">Danh mục</h3>
                <div className="space-y-2">
                  {categories.map(category => (
                    <label key={category.value} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        name="category"
                        value={category.value}
                        checked={selectedCategory === category.value}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="mr-3"
                      />
                      <span className="text-gray-700">{category.label}</span>
                      <span className="ml-auto text-gray-500 text-sm">({category.count})</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-3">Khoảng giá</h3>
                <div className="space-y-2">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="price"
                      value="all"
                      checked={priceRange === 'all'}
                      onChange={(e) => setPriceRange(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-700">Tất cả</span>
                  </label>
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="price"
                      value="under-100k"
                      checked={priceRange === 'under-100k'}
                      onChange={(e) => setPriceRange(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-700">Dưới 100,000đ</span>
                  </label>
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="price"
                      value="100k-500k"
                      checked={priceRange === '100k-500k'}
                      onChange={(e) => setPriceRange(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-700">100,000đ - 500,000đ</span>
                  </label>
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="price"
                      value="over-500k"
                      checked={priceRange === 'over-500k'}
                      onChange={(e) => setPriceRange(e.target.value)}
                      className="mr-3"
                    />
                    <span className="text-gray-700">Trên 500,000đ</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-gray-800">
                Cửa hàng cây giống & đồ cứu hộ
              </h1>
              
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="border border-gray-300 rounded-md px-4 py-2 pr-8"
              >
                <option value="popular">Phổ biến nhất</option>
                <option value="price-low">Giá thấp đến cao</option>
                <option value="price-high">Giá cao đến thấp</option>
                <option value="rating">Đánh giá cao nhất</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map(product => (
                <div key={product.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="relative">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-48 object-cover object-top"
                    />
                    {product.originalPrice && (
                      <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-sm font-medium">
                        -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                      </div>
                    )}
                    {product.isAffiliate && (
                      <div className="absolute top-2 right-2 bg-blue-500 text-white px-2 py-1 rounded text-xs">
                        Liên kết
                      </div>
                    )}
                    {!product.inStock && (
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                        <span className="text-white font-medium">Hết hàng</span>
                      </div>
                    )}
                  </div>

                  <div className="p-4">
                    <h3 className="font-semibold text-gray-800 mb-2 line-clamp-2">
                      {product.name}
                    </h3>
                    
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                      {product.description}
                    </p>

                    <div className="flex items-center mb-3">
                      <div className="flex text-yellow-400 text-sm mr-2">
                        {[...Array(5)].map((_, i) => (
                          <i key={i} className={`ri-star-${i < Math.floor(product.rating) ? 'fill' : 'line'}`}></i>
                        ))}
                      </div>
                      <span className="text-gray-600 text-sm">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-lg font-bold text-green-600">
                          {formatPrice(product.price)}
                        </div>
                        {product.originalPrice && (
                          <div className="text-sm text-gray-500 line-through">
                            {formatPrice(product.originalPrice)}
                          </div>
                        )}
                      </div>
                      
                      <button
                        disabled={!product.inStock}
                        className={`px-4 py-2 rounded-md font-medium transition-colors whitespace-nowrap ${
                          product.inStock
                            ? 'bg-green-600 text-white hover:bg-green-700 cursor-pointer'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        }`}
                      >
                        {product.inStock ? 'Mua ngay' : 'Hết hàng'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <i className="ri-shopping-cart-line text-6xl text-gray-300 mb-4"></i>
                <h3 className="text-xl font-medium text-gray-600 mb-2">
                  Không tìm thấy sản phẩm
                </h3>
                <p className="text-gray-500">
                  Hãy thử thay đổi bộ lọc để tìm sản phẩm phù hợp
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
