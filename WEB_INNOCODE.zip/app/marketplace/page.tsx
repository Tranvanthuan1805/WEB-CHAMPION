
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface MarketplaceItem {
  id: string;
  title: string;
  description: string;
  price: number;
  condition: string;
  category: string;
  images: string[];
  seller: {
    name: string;
    avatar: string;
    rating: number;
    location: string;
  };
  postedAt: string;
  views: number;
}

export default function MarketplacePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedCondition, setSelectedCondition] = useState('all');
  const [sortBy, setSortBy] = useState('newest');

  const categories = [
    { value: 'all', label: 'Tất cả', count: 156 },
    { value: 'electronics', label: 'Đồ điện tử', count: 45 },
    { value: 'furniture', label: 'Nội thất', count: 32 },
    { value: 'clothing', label: 'Quần áo', count: 28 },
    { value: 'books', label: 'Sách vở', count: 21 },
    { value: 'tools', label: 'Dụng cụ', count: 18 },
    { value: 'others', label: 'Khác', count: 12 }
  ];

  const conditions = [
    { value: 'all', label: 'Tất cả tình trạng' },
    { value: 'new', label: 'Mới (chưa sử dụng)' },
    { value: 'like-new', label: 'Như mới' },
    { value: 'good', label: 'Tốt' },
    { value: 'fair', label: 'Khá' }
  ];

  const marketplaceItems: MarketplaceItem[] = [
    {
      id: '1',
      title: 'Máy tính bảng iPad Air 2019 - 64GB',
      description: 'iPad Air 2019 64GB màu xám, còn mới 95%, pin khỏe, không trầy xước. Bán do nâng cấp lên model mới. Kèm bao da và cáp sạc.',
      price: 8500000,
      condition: 'like-new',
      category: 'electronics',
      images: [
        'https://readdy.ai/api/search-image?query=Used%20iPad%20Air%202019%20in%20excellent%20condition%2C%20silver%20color%20tablet%20with%20minimal%20wear%2C%20clean%20screen%20and%20body%2C%20second-hand%20electronics%20for%20resale&width=300&height=300&seq=ipad1&orientation=squarish'
      ],
      seller: {
        name: 'Nguyễn Minh Hạnh',
        avatar: 'https://readdy.ai/api/search-image?query=Professional%20Vietnamese%20woman%20portrait%2C%20friendly%20smile%2C%20clean%20background%2C%20user%20avatar%20photo%20for%20marketplace%20profile&width=100&height=100&seq=user1&orientation=squarish',
        rating: 4.8,
        location: 'Hà Nội'
      },
      postedAt: '2 giờ trước',
      views: 45
    },
    {
      id: '2',
      title: 'Tủ sách gỗ tự nhiên 5 tầng',
      description: 'Tủ sách gỗ tự nhiên 5 tầng, còn rất mới và đẹp. Kích thước 80x30x180cm. Lý do bán: chuyển nhà không có chỗ đặt.',
      price: 1200000,
      condition: 'good',
      category: 'furniture',
      images: [
        'https://readdy.ai/api/search-image?query=Natural%20wood%20bookshelf%20with%205%20shelves%2C%20used%20furniture%20in%20good%20condition%2C%20wooden%20storage%20unit%20for%20books%2C%20second-hand%20home%20furniture&width=300&height=300&seq=bookshelf1&orientation=squarish'
      ],
      seller: {
        name: 'Trần Văn Nam',
        avatar: 'https://readdy.ai/api/search-image?query=Middle-aged%20Vietnamese%20man%20portrait%2C%20casual%20attire%2C%20friendly%20expression%2C%20marketplace%20seller%20profile%20photo&width=100&height=100&seq=user2&orientation=squarish',
        rating: 4.6,
        location: 'TP. Hồ Chí Minh'
      },
      postedAt: '5 giờ trước',
      views: 23
    },
    {
      id: '3',
      title: 'Áo khoác denim nữ size M',
      description: 'Áo khoác jean nữ hiệu Zara, size M, màu xanh nhạt. Mặc rất ít lần, còn như mới. Phù hợp với người cao 1m55-1m65.',
      price: 250000,
      condition: 'like-new',
      category: 'clothing',
      images: [
        'https://readdy.ai/api/search-image?query=Light%20blue%20denim%20jacket%20for%20women%2C%20Zara%20brand%2C%20size%20M%2C%20nearly%20new%20condition%2C%20casual%20fashion%20clothing%20for%20resale&width=300&height=300&seq=jacket1&orientation=squarish'
      ],
      seller: {
        name: 'Lê Thị Hương',
        avatar: 'https://readdy.ai/api/search-image?query=Young%20Vietnamese%20woman%20portrait%2C%20casual%20style%2C%20marketplace%20seller%20profile%20picture%2C%20friendly%20appearance&width=100&height=100&seq=user3&orientation=squarish',
        rating: 4.9,
        location: 'Đà Nẵng'
      },
      postedAt: '1 ngày trước',
      views: 67
    },
    {
      id: '4',
      title: 'Bộ sách giáo khoa lớp 12 đầy đủ',
      description: 'Bộ sách giáo khoa lớp 12 tất cả các môn, chương trình mới. Sách còn rất mới, ít sử dụng, không viết vẽ bậy.',
      price: 480000,
      condition: 'good',
      category: 'books',
      images: [
        'https://readdy.ai/api/search-image?query=Complete%20set%20of%20Vietnamese%20high%20school%20textbooks%20grade%2012%2C%20used%20educational%20books%20in%20good%20condition%2C%20study%20materials%20for%20resale&width=300&height=300&seq=books1&orientation=squarish'
      ],
      seller: {
        name: 'Phạm Minh Tuấn',
        avatar: 'https://readdy.ai/api/search-image?query=Young%20Vietnamese%20man%20student%20portrait%2C%20casual%20attire%2C%20marketplace%20profile%20photo%2C%20clean%20background&width=100&height=100&seq=user4&orientation=squarish',
        rating: 4.7,
        location: 'Hải Phòng'
      },
      postedAt: '2 ngày trước',
      views: 89
    },
    {
      id: '5',
      title: 'Máy khoan điện Bosch GSB 120-LI',
      description: 'Máy khoan pin Bosch GSB 120-LI, còn bảo hành 8 tháng. Kèm 2 pin và bộ mũi khoan đầy đủ. Sử dụng ít, còn rất mới.',
      price: 1850000,
      condition: 'like-new',
      category: 'tools',
      images: [
        'https://readdy.ai/api/search-image?query=Bosch%20cordless%20drill%20GSB%20120-LI%20in%20excellent%20condition%2C%20power%20tool%20with%20battery%20and%20drill%20bits%20set%2C%20professional%20equipment%20for%20resale&width=300&height=300&seq=drill1&orientation=squarish'
      ],
      seller: {
        name: 'Hoàng Văn Đức',
        avatar: 'https://readdy.ai/api/search-image?query=Middle-aged%20Vietnamese%20craftsman%20portrait%2C%20work%20attire%2C%20experienced%20handyman%20profile%20photo%20for%20marketplace&width=100&height=100&seq=user5&orientation=squarish',
        rating: 4.8,
        location: 'Hà Nội'
      },
      postedAt: '3 ngày trước',
      views: 34
    },
    {
      id: '6',
      title: 'Ghế gaming DXRacer Formula Series',
      description: 'Ghế gaming DXRacer màu đen đỏ, series Formula. Còn rất mới, tất cả chức năng hoạt động tốt. Tặng kèm gối tựa đầu và lưng.',
      price: 3200000,
      condition: 'good',
      category: 'furniture',
      images: [
        'https://readdy.ai/api/search-image?query=DXRacer%20gaming%20chair%20Formula%20series%20in%20black%20and%20red%2C%20used%20office%20furniture%20in%20good%20condition%2C%20ergonomic%20chair%20for%20resale&width=300&height=300&seq=chair1&orientation=squarish'
      ],
      seller: {
        name: 'Nguyễn Thanh Long',
        avatar: 'https://readdy.ai/api/search-image?query=Young%20Vietnamese%20gamer%20portrait%2C%20casual%20modern%20style%2C%20marketplace%20seller%20profile%20picture&width=100&height=100&seq=user6&orientation=squarish',
        rating: 4.5,
        location: 'TP. Hồ Chí Minh'
      },
      postedAt: '4 ngày trước',
      views: 156
    }
  ];

  const filteredItems = marketplaceItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesCondition = selectedCondition === 'all' || item.condition === selectedCondition;
    return matchesCategory && matchesCondition;
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  const getConditionLabel = (condition: string) => {
    const conditionMap: { [key: string]: string } = {
      'new': 'Mới',
      'like-new': 'Như mới',
      'good': 'Tốt',
      'fair': 'Khá'
    };
    return conditionMap[condition] || condition;
  };

  const getConditionColor = (condition: string) => {
    const colorMap: { [key: string]: string } = {
      'new': 'bg-green-100 text-green-800',
      'like-new': 'bg-blue-100 text-blue-800',
      'good': 'bg-yellow-100 text-yellow-800',
      'fair': 'bg-orange-100 text-orange-800'
    };
    return colorMap[condition] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">
              Chợ tái chế cộng đồng
            </h1>
            <p className="text-gray-600">
              Nơi mua bán, trao đổi đồ cũ giữa các thành viên cộng đồng
            </p>
          </div>
          
          <Link 
            href="/marketplace/post"
            className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-add-line mr-2"></i>
            Đăng bài
          </Link>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-1/4">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-24">
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Bộ lọc</h2>
              
              {/* Categories */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-3">Danh mục</h3>
                <div className="space-y-2">
                  {categories.map(category => (
                    <label key={category.value} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        name="category"
                        value={category.value}
                        checked={selectedCategory === category.value}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="mr-3"
                      />
                      <span className="text-gray-700">{category.label}</span>
                      <span className="ml-auto text-gray-500 text-sm">({category.count})</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Condition */}
              <div className="mb-6">
                <h3 className="font-medium text-gray-700 mb-3">Tình trạng</h3>
                <div className="space-y-2">
                  {conditions.map(condition => (
                    <label key={condition.value} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        name="condition"
                        value={condition.value}
                        checked={selectedCondition === condition.value}
                        onChange={(e) => setSelectedCondition(e.target.value)}
                        className="mr-3"
                      />
                      <span className="text-gray-700">{condition.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <div className="text-gray-600">
                Hiển thị {filteredItems.length} sản phẩm
              </div>
              
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="border border-gray-300 rounded-md px-4 py-2 pr-8"
              >
                <option value="newest">Mới nhất</option>
                <option value="oldest">Cũ nhất</option>
                <option value="price-low">Giá thấp đến cao</option>
                <option value="price-high">Giá cao đến thấp</option>
                <option value="popular">Xem nhiều nhất</option>
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredItems.map(item => (
                <div key={item.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                  <div className="flex">
                    <div className="w-1/3">
                      <img
                        src={item.images[0]}
                        alt={item.title}
                        className="w-full h-48 object-cover object-top"
                      />
                    </div>
                    
                    <div className="w-2/3 p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-800 line-clamp-2 flex-1">
                          {item.title}
                        </h3>
                        <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getConditionColor(item.condition)}`}>
                          {getConditionLabel(item.condition)}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                        {item.description}
                      </p>

                      <div className="text-xl font-bold text-green-600 mb-3">
                        {formatPrice(item.price)}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <img
                            src={item.seller.avatar}
                            alt={item.seller.name}
                            className="w-8 h-8 rounded-full mr-2"
                          />
                          <div>
                            <div className="text-sm font-medium text-gray-800">
                              {item.seller.name}
                            </div>
                            <div className="text-xs text-gray-500 flex items-center">
                              <i className="ri-star-fill text-yellow-400 mr-1"></i>
                              {item.seller.rating}
                              <span className="mx-1">•</span>
                              <i className="ri-map-pin-line mr-1"></i>
                              {item.seller.location}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-3 pt-3 border-t text-xs text-gray-500">
                        <span>{item.postedAt}</span>
                        <span>
                          <i className="ri-eye-line mr-1"></i>
                          {item.views} lượt xem
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <div className="text-center py-12">
                <i className="ri-shopping-bag-line text-6xl text-gray-300 mb-4"></i>
                <h3 className="text-xl font-medium text-gray-600 mb-2">
                  Không tìm thấy sản phẩm
                </h3>
                <p className="text-gray-500">
                  Hãy thử thay đổi bộ lọc để tìm sản phẩm phù hợp
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
