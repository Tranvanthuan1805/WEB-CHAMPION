
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const heroSlides = [
    {
      title: "Serve the Community",
      subtitle: "Phụng sự xã hội",
      description: "Hỗ trợ cộng đồng nông thôn, ứng phó thiên tai và bảo vệ môi trường",
      image: "https://readdy.ai/api/search-image?query=Vietnamese%20rural%20community%20farmers%20working%20together%20in%20green%20rice%20fields%20with%20mountains%20in%20background%2C%20helping%20each%20other%20during%20harvest%20season%2C%20warm%20sunlight%2C%20peaceful%20countryside%20atmosphere%2C%20community%20spirit%2C%20traditional%20Vietnamese%20village&width=800&height=600&seq=hero1&orientation=landscape"
    },
    {
      title: "Cảnh báo thời tiết",
      subtitle: "Weather Alert System",
      description: "Theo dõi thời tiết và cảnh báo thiên tai kịp thời cho cộng đồng",
      image: "https://readdy.ai/api/search-image?query=Weather%20monitoring%20system%20with%20storm%20clouds%20and%20lightning%20over%20Vietnamese%20countryside%2C%20early%20warning%20system%20protecting%20rural%20communities%2C%20dramatic%20sky%20with%20safety%20equipment%2C%20technology%20helping%20farmers&width=800&height=600&seq=hero2&orientation=landscape"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const features = [
    {
      icon: 'ri-cloud-line',
      title: 'Dự báo thời tiết',
      description: 'Theo dõi thời tiết và cảnh báo thiên tai chính xác',
      link: '/weather'
    },
    {
      icon: 'ri-emergency-line',
      title: 'Cứu hộ SOS',
      description: 'Gửi tín hiệu cứu hộ khẩn cấp khi gặp nguy hiểm',
      link: '/sos'
    },
    {
      icon: 'ri-plant-line',
      title: 'Tư vấn cây trồng',
      description: 'Gợi ý cây trồng phù hợp theo vùng miền và khí hậu',
      link: '/plants'
    },
    {
      icon: 'ri-shopping-cart-line',
      title: 'Cửa hàng',
      description: 'Bán cây giống và đồ cứu hộ chất lượng cao',
      link: '/shop'
    },
    {
      icon: 'ri-recycle-line',
      title: 'Chợ tái chế',
      description: 'Mua bán đồ tái chế, bảo vệ môi trường',
      link: '/marketplace'
    },
    {
      icon: 'ri-book-open-line',
      title: 'Blog cộng đồng',
      description: 'Chia sẻ kinh nghiệm và kiến thức hữu ích',
      link: '/blog'
    }
  ];

  const stats = [
    { number: '10,000+', label: 'Người dùng' },
    { number: '500+', label: 'Cây trồng' },
    { number: '1,000+', label: 'Cảnh báo thời tiết' },
    { number: '95%', label: 'Độ chính xác' }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000"
          style={{ 
            backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url(${heroSlides[currentSlide].image})`
          }}
        />
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold mb-4 animate-fade-in">
            {heroSlides[currentSlide].title}
          </h1>
          <h2 className="text-2xl md:text-4xl font-pacifico text-green-400 mb-6">
            {heroSlides[currentSlide].subtitle}
          </h2>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            {heroSlides[currentSlide].description}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/weather"
              className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              Xem thời tiết
            </Link>
            <Link 
              href="/sos"
              className="bg-red-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-red-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              Cứu hộ SOS
            </Link>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-colors cursor-pointer ${
                index === currentSlide ? 'bg-white' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              Dịch vụ của chúng tôi
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Cung cấp các giải pháp toàn diện hỗ trợ cộng đồng nông thôn
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Link 
                key={index}
                href={feature.link}
                className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 cursor-pointer"
              >
                <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-6 mx-auto">
                  <i className={`${feature.icon} text-3xl text-green-600`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4 text-center">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-center">
                  {feature.description}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-green-600">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center text-white">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-4xl font-bold mb-2">{stat.number}</div>
                <div className="text-lg">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Tham gia cộng đồng ngay hôm nay
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Cùng nhau xây dựng một cộng đồng mạnh mẽ, hỗ trợ lẫn nhau trong mọi hoàn cảnh
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              href="/auth/register"
              className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              Đăng ký ngay
            </Link>
            <Link 
              href="/about"
              className="border-2 border-green-600 text-green-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-600 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              Tìm hiểu thêm
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <Chatbot />

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
      `}</style>
    </div>
  );
}
