
'use client';

import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface Plant {
  id: string;
  name: string;
  scientificName: string;
  region: string[];
  season: string;
  climate: string;
  soilType: string;
  waterNeed: string;
  growthTime: string;
  difficulty: string;
  benefits: string[];
  image: string;
  description: string;
}

export default function PlantsPage() {
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedSeason, setSelectedSeason] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const regions = [
    { value: 'all', label: 'Tất cả vùng' },
    { value: 'bac-bo', label: 'Bắc Bộ' },
    { value: 'trung-bo', label: 'Trung Bộ' },
    { value: 'nam-bo', label: 'Nam Bộ' },
    { value: 'tay-nguyen', label: 'Tây Nguyên' }
  ];

  const seasons = [
    { value: 'all', label: 'Tất cả mùa' },
    { value: 'xuan', label: 'Mùa xuân' },
    { value: 'he', label: 'Mùa hè' },
    { value: 'thu', label: 'Mùa thu' },
    { value: 'dong', label: 'Mùa đông' }
  ];

  const mockPlants: Plant[] = [
    {
      id: '1',
      name: 'Lúa tám xoan',
      scientificName: 'Oryza sativa',
      region: ['bac-bo', 'trung-bo'],
      season: 'he',
      climate: 'Ôn đới, cận nhiệt đới',
      soilType: 'Đất phù sa, đất sét',
      waterNeed: 'Nhiều nước',
      growthTime: '100-110 ngày',
      difficulty: 'Trung bình',
      benefits: ['Nguồn lương thực chính', 'Thu nhập ổn định', 'Phù hợp khí hậu'],
      image: 'https://readdy.ai/api/search-image?query=Vietnamese%20traditional%20rice%20variety%20growing%20in%20flooded%20rice%20fields%2C%20green%20rice%20plants%20in%20paddies%20with%20farmers%20working%2C%20rural%20Vietnam%20agriculture%20landscape%2C%20traditional%20farming%20methods%2C%20lush%20green%20rice%20crops&width=400&height=300&seq=rice1&orientation=landscape',
      description: 'Giống lúa truyền thống của Việt Nam, thích nghi tốt với khí hậu phía Bắc, chất lượng gạo thơm ngon.'
    },
    {
      id: '2',
      name: 'Cà chua bi',
      scientificName: 'Solanum lycopersicum',
      region: ['bac-bo', 'trung-bo', 'nam-bo'],
      season: 'xuan',
      climate: 'Nhiệt đới, cận nhiệt đới',
      soilType: 'Đất tơi xốp, thoát nước tốt',
      waterNeed: 'Vừa phải',
      growthTime: '70-80 ngày',
      difficulty: 'Dễ',
      benefits: ['Giá trị dinh dương cao', 'Dễ trồng', 'Thu hoạch nhanh'],
      image: 'https://readdy.ai/api/search-image?query=Small%20cherry%20tomatoes%20growing%20on%20vines%20in%20Vietnamese%20greenhouse%2C%20bright%20red%20cherry%20tomatoes%20hanging%20in%20clusters%2C%20healthy%20green%20tomato%20plants%2C%20modern%20agricultural%20setting%20in%20Vietnam&width=400&height=300&seq=tomato1&orientation=landscape',
      description: 'Cà chua bi dễ trồng, phù hợp với nhiều vùng khí hậu, có thể trồng quanh năm tại Nam Bộ.'
    },
    {
      id: '3',
      name: 'Rau muống',
      scientificName: 'Ipomoea aquatica',
      region: ['nam-bo', 'trung-bo'],
      season: 'he',
      climate: 'Nhiệt đới ẩm',
      soilType: 'Đất ẩm, gần nguồn nước',
      waterNeed: 'Rất nhiều',
      growthTime: '25-30 ngày',
      difficulty: 'Rất dễ',
      benefits: ['Thu hoạch nhanh', 'Giá trị dinh dương', 'Dễ chăm sóc'],
      image: 'https://readdy.ai/api/search-image?query=Water%20spinach%20vegetables%20growing%20in%20flooded%20fields%20in%20Vietnam%2C%20green%20leafy%20water%20spinach%20plants%20in%20wetland%20agriculture%2C%20traditional%20Vietnamese%20vegetable%20farming%2C%20lush%20green%20water%20spinach%20crops&width=400&height=300&seq=spinach1&orientation=landscape',
      description: 'Rau ăn lá phổ biến, thích nghi với vùng có nhiều nước, thu hoạch liên tục.'
    },
    {
      id: '4',
      name: 'Cà phê Robusta',
      scientificName: 'Coffea canephora',
      region: ['tay-nguyen', 'nam-bo'],
      season: 'dong',
      climate: 'Nhiệt đới cao nguyên',
      soilType: 'Đất đỏ bazan',
      waterNeed: 'Trung bình',
      growthTime: '3-4 năm',
      difficulty: 'Khó',
      benefits: ['Giá trị kinh tế cao', 'Xuất khẩu', 'Thu nhập dài hạn'],
      image: 'https://readdy.ai/api/search-image?query=Vietnamese%20robusta%20coffee%20plantation%20in%20highland%20region%2C%20coffee%20trees%20with%20red%20coffee%20cherries%2C%20terraced%20coffee%20farms%20in%20Tay%20Nguyen%20Vietnam%2C%20traditional%20coffee%20cultivation%20on%20hillsides&width=400&height=300&seq=coffee1&orientation=landscape',
      description: 'Cây công nghiệp quan trọng của Tây Nguyên, cần kỹ thuật chăm sóc chuyên môn.'
    },
    {
      id: '5',
      name: 'Khoai lang',
      scientificName: 'Ipomoea batatas',
      region: ['bac-bo', 'trung-bo', 'nam-bo'],
      season: 'thu',
      climate: 'Nhiệt đới, cận nhiệt đới',
      soilType: 'Đất cát, đất tơi xốp',
      waterNeed: 'Ít',
      growthTime: '90-120 ngày',
      difficulty: 'Dễ',
      benefits: ['Chống hạn tốt', 'Giá trị dinh dương', 'Dễ bảo quản'],
      image: 'https://readdy.ai/api/search-image?query=Sweet%20potato%20plants%20growing%20in%20Vietnamese%20agricultural%20field%2C%20green%20sweet%20potato%20vines%20spreading%20across%20farmland%2C%20healthy%20sweet%20potato%20cultivation%20with%20orange%20tubers%20visible%2C%20traditional%20Vietnamese%20farming&width=400&height=300&seq=potato1&orientation=landscape',
      description: 'Cây trồng chống chịu tốt, phù hợp với nhiều loại đất, ít sâu bệnh.'
    },
    {
      id: '6',
      name: 'Dưa hấu',
      scientificName: 'Citrullus lanatus',
      region: ['trung-bo', 'nam-bo'],
      season: 'he',
      climate: 'Nhiệt đới khô',
      soilType: 'Đất cát pha',
      waterNeed: 'Nhiều (giai đoạn đầu)',
      growthTime: '85-100 ngày',
      difficulty: 'Trung bình',
      benefits: ['Giá trị thương mại cao', 'Phù hợp xuất khẩu', 'Thu nhập tốt'],
      image: 'https://readdy.ai/api/search-image?query=Watermelon%20farming%20in%20Vietnam%2C%20large%20watermelons%20growing%20on%20vines%20in%20sandy%20soil%20fields%2C%20Vietnamese%20farmers%20harvesting%20watermelons%2C%20green%20watermelon%20plants%20spreading%20across%20agricultural%20land&width=400&height=300&seq=watermelon1&orientation=landscape',
      description: 'Cây ăn quả có giá trị thương mại cao, thích hợp vùng có nắng nhiều và đất thoát nước tốt.'
    }
  ];

  const filteredPlants = mockPlants.filter(plant => {
    const matchesRegion = selectedRegion === 'all' || plant.region.includes(selectedRegion);
    const matchesSeason = selectedSeason === 'all' || plant.season === selectedSeason;
    const matchesSearch = plant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         plant.scientificName.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesRegion && matchesSeason && matchesSearch;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Dễ': case 'Rất dễ': return 'bg-green-100 text-green-800';
      case 'Trung bình': return 'bg-yellow-100 text-yellow-800';
      case 'Khó': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-600 mb-4">
            Hệ thống tư vấn cây trồng
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Gợi ý cây trồng phù hợp theo vùng miền, khí hậu và mùa vụ để tối ưu hóa năng suất
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tìm kiếm cây trồng
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Tên cây trồng..."
                  className="w-full border border-gray-300 rounded-md pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
                />
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Vùng miền
              </label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 pr-8"
              >
                {regions.map(region => (
                  <option key={region.value} value={region.value}>
                    {region.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mùa vụ
              </label>
              <select
                value={selectedSeason}
                onChange={(e) => setSelectedSeason(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-green-500 pr-8"
              >
                {seasons.map(season => (
                  <option key={season.value} value={season.value}>
                    {season.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button className="w-full bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-search-line mr-2"></i>
                Tìm kiếm
              </button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-800">
              Kết quả tìm kiếm ({filteredPlants.length} cây trồng)
            </h2>
            <div className="text-sm text-gray-600">
              Sắp xếp theo: <span className="font-medium">Phù hợp nhất</span>
            </div>
          </div>
        </div>

        {/* Plants Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlants.map((plant) => (
            <div key={plant.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="relative">
                <img
                  src={plant.image}
                  alt={plant.name}
                  className="w-full h-48 object-cover object-top"
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(plant.difficulty)}`}>
                    {plant.difficulty}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="mb-4">
                  <h3 className="text-xl font-semibold text-gray-800 mb-1">{plant.name}</h3>
                  <p className="text-sm italic text-gray-600">{plant.scientificName}</p>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-gray-600">
                    <i className="ri-map-pin-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    <span>Vùng: {plant.region.join(', ')}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <i className="ri-calendar-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    <span>Mùa: {plant.season}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <i className="ri-time-line w-4 h-4 flex items-center justify-center mr-2"></i>
                    <span>Thời gian: {plant.growthTime}</span>
                  </div>
                </div>

                <p className="text-gray-700 text-sm mb-4 line-clamp-3">
                  {plant.description}
                </p>

                <div className="flex flex-wrap gap-1 mb-4">
                  {plant.benefits.slice(0, 2).map((benefit, index) => (
                    <span key={index} className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                      {benefit}
                    </span>
                  ))}
                  {plant.benefits.length > 2 && (
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                      +{plant.benefits.length - 2}
                    </span>
                  )}
                </div>

                <button className="w-full bg-green-600 text-white py-2 rounded-md hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
                  Xem chi tiết
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredPlants.length === 0 && (
          <div className="text-center py-12">
            <i className="ri-plant-line text-6xl text-gray-300 mb-4"></i>
            <h3 className="text-xl font-medium text-gray-600 mb-2">Không tìm thấy cây trồng phù hợp</h3>
            <p className="text-gray-500">Hãy thử thay đổi bộ lọc để tìm kiếm cây trồng khác</p>
          </div>
        )}
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
