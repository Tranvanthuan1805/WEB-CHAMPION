
'use client';

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface WeatherData {
  location: string;
  temperature: number;
  humidity: number;
  windSpeed: number;
  condition: string;
  icon: string;
  forecast: Array<{
    day: string;
    temp: number;
    condition: string;
    icon: string;
  }>;
}

interface DisasterAlert {
  id: string;
  type: string;
  level: string;
  message: string;
  area: string;
  time: string;
}

export default function WeatherPage() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [alerts, setAlerts] = useState<DisasterAlert[]>([]);
  const [location, setLocation] = useState('Hà Nội');

  const mockWeatherData: WeatherData = {
    location: 'Hà Nội',
    temperature: 28,
    humidity: 75,
    windSpeed: 12,
    condition: 'Có mây',
    icon: 'ri-cloudy-line',
    forecast: [
      { day: 'Hôm nay', temp: 28, condition: 'Có mây', icon: 'ri-cloudy-line' },
      { day: 'Mai', temp: 30, condition: 'Nắng', icon: 'ri-sun-line' },
      { day: 'T3', temp: 26, condition: 'Mưa', icon: 'ri-rainy-line' },
      { day: 'T4', temp: 24, condition: 'Mưa to', icon: 'ri-heavy-showers-line' },
      { day: 'T5', temp: 27, condition: 'Nắng ít mây', icon: 'ri-sun-cloudy-line' },
      { day: 'T6', temp: 29, condition: 'Nắng', icon: 'ri-sun-line' },
      { day: 'T7', temp: 31, condition: 'Nắng gắt', icon: 'ri-sun-line' }
    ]
  };

  const mockAlerts: DisasterAlert[] = [
    {
      id: '1',
      type: 'Bão',
      level: 'Cảnh báo cam',
      message: 'Bão số 4 đang tiến vào vùng biển Bắc Bộ, gió mạnh cấp 8-10',
      area: 'Quảng Ninh, Hải Phòng',
      time: '2 giờ trước'
    },
    {
      id: '2',
      type: 'Lũ quét',
      level: 'Cảnh báo vàng',
      message: 'Nguy cơ lũ quét tại các tỉnh miền núi phía Bắc do mưa lớn kéo dài',
      area: 'Lào Cai, Yên Bái, Sơn La',
      time: '4 giờ trước'
    },
    {
      id: '3',
      type: 'Hạn hán',
      level: 'Cảnh báo xanh',
      message: 'Tình trạng thiếu nước tưới tiêu tại các tỉnh Nam Trung Bộ',
      area: 'Ninh Thuận, Bình Thuận',
      time: '1 ngày trước'
    }
  ];

  useEffect(() => {
    setWeatherData(mockWeatherData);
    setAlerts(mockAlerts);
  }, []);

  const getAlertColor = (level: string) => {
    switch (level) {
      case 'Cảnh báo đỏ': return 'bg-red-100 border-red-500 text-red-800';
      case 'Cảnh báo cam': return 'bg-orange-100 border-orange-500 text-orange-800';
      case 'Cảnh báo vàng': return 'bg-yellow-100 border-yellow-500 text-yellow-800';
      case 'Cảnh báo xanh': return 'bg-blue-100 border-blue-500 text-blue-800';
      default: return 'bg-gray-100 border-gray-500 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-800">Thời tiết & Cảnh báo thiên tai</h1>
          
          <div className="flex items-center space-x-4">
            <select 
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="border border-gray-300 rounded-md px-4 py-2 pr-8"
            >
              <option value="Hà Nội">Hà Nội</option>
              <option value="Hồ Chí Minh">TP. Hồ Chí Minh</option>
              <option value="Đà Nẵng">Đà Nẵng</option>
              <option value="Cần Thơ">Cần Thơ</option>
              <option value="Hải Phòng">Hải Phòng</option>
            </select>
            
            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
              <i className="ri-refresh-line mr-2"></i>
              Cập nhật
            </button>
          </div>
        </div>

        {/* Current Weather */}
        {weatherData && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <div className="flex items-center mb-4">
                  <i className="ri-map-pin-line text-green-600 mr-2"></i>
                  <h2 className="text-2xl font-semibold text-gray-800">{weatherData.location}</h2>
                </div>
                
                <div className="flex items-center mb-6">
                  <div className="w-20 h-20 flex items-center justify-center bg-blue-100 rounded-full mr-6">
                    <i className={`${weatherData.icon} text-4xl text-blue-600`}></i>
                  </div>
                  <div>
                    <div className="text-5xl font-bold text-gray-800">{weatherData.temperature}°C</div>
                    <div className="text-lg text-gray-600">{weatherData.condition}</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <i className="ri-drop-line text-blue-600 mr-2"></i>
                    <span className="text-gray-600">Độ ẩm</span>
                  </div>
                  <div className="text-2xl font-semibold text-gray-800">{weatherData.humidity}%</div>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <i className="ri-windy-line text-green-600 mr-2"></i>
                    <span className="text-gray-600">Tốc độ gió</span>
                  </div>
                  <div className="text-2xl font-semibold text-gray-800">{weatherData.windSpeed} km/h</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 7-day Forecast */}
        {weatherData && (
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <h3 className="text-xl font-semibold text-gray-800 mb-6">Dự báo 7 ngày</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              {weatherData.forecast.map((day, index) => (
                <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm text-gray-600 mb-2">{day.day}</div>
                  <div className="w-10 h-10 flex items-center justify-center bg-blue-100 rounded-full mx-auto mb-2">
                    <i className={`${day.icon} text-lg text-blue-600`}></i>
                  </div>
                  <div className="text-lg font-semibold text-gray-800">{day.temp}°C</div>
                  <div className="text-xs text-gray-600">{day.condition}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Disaster Alerts */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold text-gray-800">Cảnh báo thiên tai</h3>
            <div className="flex items-center text-sm text-gray-600">
              <i className="ri-notification-line mr-1"></i>
              Cập nhật realtime
            </div>
          </div>

          <div className="space-y-4">
            {alerts.map((alert) => (
              <div 
                key={alert.id}
                className={`border-l-4 p-4 rounded-lg ${getAlertColor(alert.level)}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <span className="font-semibold mr-2">{alert.type}</span>
                      <span className="text-xs px-2 py-1 bg-white rounded-full font-medium">
                        {alert.level}
                      </span>
                    </div>
                    <p className="mb-2">{alert.message}</p>
                    <div className="flex items-center text-sm">
                      <i className="ri-map-pin-line mr-1"></i>
                      <span className="mr-4">{alert.area}</span>
                      <i className="ri-time-line mr-1"></i>
                      <span>{alert.time}</span>
                    </div>
                  </div>
                  <button className="ml-4 text-gray-500 hover:text-gray-700 cursor-pointer">
                    <i className="ri-more-2-line"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 text-center">
            <button className="text-green-600 hover:text-green-700 font-medium cursor-pointer">
              Xem tất cả cảnh báo
              <i className="ri-arrow-right-line ml-1"></i>
            </button>
          </div>
        </div>
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
