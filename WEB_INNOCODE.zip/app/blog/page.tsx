
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Chatbot from '@/components/Chatbot';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: {
    name: string;
    avatar: string;
  };
  category: string;
  tags: string[];
  publishedAt: string;
  readTime: number;
  views: number;
  comments: number;
  image: string;
}

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: 'Tất cả bài viết', count: 48 },
    { value: 'farming', label: 'Nông nghiệp', count: 18 },
    { value: 'disaster', label: 'Thiên tai', count: 12 },
    { value: 'environment', label: 'Môi trường', count: 10 },
    { value: 'tips', label: 'Mẹo hay', count: 8 }
  ];

  const blogPosts: BlogPost[] = [
    {
      id: '1',
      title: 'Cách trồng lúa thích ứng với biến đổi khí hậu',
      excerpt: 'Hướng dẫn chi tiết về các kỹ thuật trồng lúa hiện đại giúp nông dân thích ứng với thời tiết thay đổi và tăng năng suất.',
      content: '',
      author: {
        name: 'TS. Nguyễn Văn Minh',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20agricultural%20expert%20portrait%2C%20middle-aged%20man%20with%20glasses%2C%20professional%20appearance%2C%20scientist%20in%20farming%20field&width=100&height=100&seq=expert1&orientation=squarish'
      },
      category: 'farming',
      tags: ['lúa', 'khí hậu', 'nông nghiệp'],
      publishedAt: '2 ngày trước',
      readTime: 8,
      views: 1247,
      comments: 23,
      image: 'https://readdy.ai/api/search-image?query=Modern%20rice%20farming%20techniques%20in%20Vietnam%2C%20farmers%20using%20climate-adaptive%20methods%2C%20green%20rice%20paddies%20with%20irrigation%20systems%2C%20sustainable%20agriculture&width=400&height=250&seq=rice_blog1&orientation=landscape'
    },
    {
      id: '2',
      title: 'Chuẩn bị ứng phó bão lũ cho gia đình nông thôn',
      excerpt: 'Checklist đầy đủ và hướng dẫn chuẩn bị trước mùa bão để bảo vệ gia đình, tài sản và cây trồng an toàn.',
      content: '',
      author: {
        name: 'Trần Thị Hạnh',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20disaster%20preparedness%20expert%2C%20middle-aged%20woman%20in%20professional%20attire%2C%20emergency%20management%20specialist%20portrait&width=100&height=100&seq=expert2&orientation=squarish'
      },
      category: 'disaster',
      tags: ['bão lũ', 'chuẩn bị', 'an toàn'],
      publishedAt: '3 ngày trước',
      readTime: 12,
      views: 2156,
      comments: 45,
      image: 'https://readdy.ai/api/search-image?query=Rural%20Vietnamese%20family%20preparing%20for%20storm%20season%2C%20securing%20house%20and%20farm%20equipment%2C%20emergency%20supplies%20and%20flood%20preparation%20activities&width=400&height=250&seq=storm_prep1&orientation=landscape'
    },
    {
      id: '3',
      title: '5 loại cây trồng chịu hạn tốt nhất cho miền Trung',
      excerpt: 'Gợi ý các loại cây trồng có khả năng chịu hạn cao, phù hợp với điều kiện khí hậu khô hạn tại các tỉnh miền Trung.',
      content: '',
      author: {
        name: 'Lê Hoàng Nam',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20plant%20specialist%2C%20young%20man%20in%20field%20work%20clothes%2C%20agricultural%20researcher%20with%20plants%20in%20background&width=100&height=100&seq=expert3&orientation=squarish'
      },
      category: 'farming',
      tags: ['chịu hạn', 'miền trung', 'cây trồng'],
      publishedAt: '5 ngày trước',
      readTime: 6,
      views: 892,
      comments: 18,
      image: 'https://readdy.ai/api/search-image?query=Drought-resistant%20crops%20growing%20in%20Central%20Vietnam%2C%20hardy%20plants%20in%20dry%20climate%20conditions%2C%20sustainable%20farming%20in%20arid%20regions&width=400&height=250&seq=drought_crops1&orientation=landscape'
    },
    {
      id: '4',
      title: 'Tái chế phế phẩm nông nghiệp thành phân bón hữu cơ',
      excerpt: 'Hướng dẫn cách biến rơm rạ, thực vật phế thải thành phân bón hữu cơ chất lượng cao cho đất trồng.',
      content: '',
      author: {
        name: 'Phạm Minh Đức',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20environmental%20specialist%2C%20young%20man%20with%20eco-friendly%20farming%20background%2C%20organic%20agriculture%20expert%20portrait&width=100&height=100&seq=expert4&orientation=squarish'
      },
      category: 'environment',
      tags: ['tái chế', 'phân bón', 'hữu cơ'],
      publishedAt: '1 tuần trước',
      readTime: 10,
      views: 1534,
      comments: 31,
      image: 'https://readdy.ai/api/search-image?query=Composting%20agricultural%20waste%20into%20organic%20fertilizer%2C%20Vietnamese%20farmers%20recycling%20rice%20straw%20and%20plant%20materials%2C%20sustainable%20farming%20practices&width=400&height=250&seq=compost1&orientation=landscape'
    },
    {
      id: '5',
      title: 'Nhận biết dấu hiệu sâu bệnh hại cây trồng sớm',
      excerpt: 'Cách nhận biết các dấu hiệu sớm của sâu bệnh hại và biện pháp phòng chống hiệu quả, an toàn.',
      content: '',
      author: {
        name: 'Dr. Võ Thị Lan',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20plant%20pathology%20expert%2C%20middle-aged%20woman%20examining%20plants%2C%20agricultural%20scientist%20with%20magnifying%20glass&width=100&height=100&seq=expert5&orientation=squarish'
      },
      category: 'farming',
      tags: ['sâu bệnh', 'phòng chống', 'cây trồng'],
      publishedAt: '1 tuần trước',
      readTime: 7,
      views: 967,
      comments: 22,
      image: 'https://readdy.ai/api/search-image?query=Plant%20disease%20identification%20in%20Vietnamese%20agriculture%2C%20close-up%20of%20crop%20leaves%20showing%20pest%20damage%2C%20farmer%20examining%20plants%20for%20early%20disease%20detection&width=400&height=250&seq=pest_control1&orientation=landscape'
    },
    {
      id: '6',
      title: 'Xây dựng hệ thống tưới tiêu tiết kiệm nước',
      excerpt: 'Thiết kế và lắp đặt hệ thống tưới nhỏ giọt, tưới phun sương giúp tiết kiệm nước và tăng hiệu quả canh tác.',
      content: '',
      author: {
        name: 'Kỹ sư Đinh Văn Tuấn',
        avatar: 'https://readdy.ai/api/search-image?query=Vietnamese%20irrigation%20engineer%2C%20middle-aged%20man%20with%20technical%20equipment%2C%20water%20management%20specialist%20in%20agricultural%20setting&width=100&height=100&seq=expert6&orientation=squarish'
      },
      category: 'tips',
      tags: ['tưới tiêu', 'tiết kiệm nước', 'hệ thống'],
      publishedAt: '2 tuần trước',
      readTime: 15,
      views: 1823,
      comments: 38,
      image: 'https://readdy.ai/api/search-image?query=Modern%20drip%20irrigation%20system%20in%20Vietnamese%20farm%2C%20water-saving%20agricultural%20technology%2C%20efficient%20watering%20methods%20for%20crops&width=400&height=250&seq=irrigation1&orientation=landscape'
    }
  ];

  const filteredPosts = blogPosts.filter(post => 
    selectedCategory === 'all' || post.category === selectedCategory
  );

  const featuredPost = blogPosts[0];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">
            Blog cộng đồng
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Chia sẻ kinh nghiệm, kiến thức về nông nghiệp, ứng phó thiên tai và bảo vệ môi trường
          </p>
        </div>

        {/* Featured Post */}
        <div className="mb-12">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img
                  src={featuredPost.image}
                  alt={featuredPost.title}
                  className="w-full h-64 md:h-full object-cover object-top"
                />
              </div>
              <div className="md:w-1/2 p-8">
                <div className="flex items-center mb-4">
                  <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    Nổi bật
                  </span>
                  <span className="ml-3 text-gray-500 text-sm">
                    {featuredPost.readTime} phút đọc
                  </span>
                </div>
                
                <h2 className="text-2xl font-bold text-gray-800 mb-4">
                  {featuredPost.title}
                </h2>
                
                <p className="text-gray-600 mb-6">
                  {featuredPost.excerpt}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img
                      src={featuredPost.author.avatar}
                      alt={featuredPost.author.name}
                      className="w-10 h-10 rounded-full mr-3"
                    />
                    <div>
                      <div className="font-medium text-gray-800">
                        {featuredPost.author.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {featuredPost.publishedAt}
                      </div>
                    </div>
                  </div>
                  
                  <Link 
                    href={`/blog/${featuredPost.id}`}
                    className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Đọc tiếp
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-1/4">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-24">
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Danh mục</h2>
              
              <div className="space-y-2">
                {categories.map(category => (
                  <button
                    key={category.value}
                    onClick={() => setSelectedCategory(category.value)}
                    className={`w-full text-left p-3 rounded-lg transition-colors cursor-pointer ${
                      selectedCategory === category.value
                        ? 'bg-green-100 text-green-700'
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{category.label}</span>
                      <span className="text-sm text-gray-500">({category.count})</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-8">
                <Link 
                  href="/blog/write"
                  className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap text-center block"
                >
                  <i className="ri-edit-line mr-2"></i>
                  Viết bài mới
                </Link>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800">
                {selectedCategory === 'all' ? 'Tất cả bài viết' : categories.find(c => c.value === selectedCategory)?.label}
              </h2>
              <div className="text-gray-600">
                {filteredPosts.length} bài viết
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredPosts.slice(1).map(post => (
                <article key={post.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-48 object-cover object-top"
                  />
                  
                  <div className="p-6">
                    <div className="flex items-center mb-3">
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                        {categories.find(c => c.value === post.category)?.label}
                      </span>
                      <span className="ml-3 text-gray-500 text-sm">
                        {post.readTime} phút đọc
                      </span>
                    </div>
                    
                    <h3 className="text-lg font-semibold text-gray-800 mb-3 line-clamp-2">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {post.tags.map((tag, tagIndex) => (
                        <span key={tagIndex} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                          #{tag}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <img
                          src={post.author.avatar}
                          alt={post.author.name}
                          className="w-8 h-8 rounded-full mr-2"
                        />
                        <div>
                          <div className="text-sm font-medium text-gray-800">
                            {post.author.name}
                          </div>
                          <div className="text-xs text-gray-500">
                            {post.publishedAt}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>
                          <i className="ri-eye-line mr-1"></i>
                          {post.views}
                        </span>
                        <span>
                          <i className="ri-chat-3-line mr-1"></i>
                          {post.comments}
                        </span>
                      </div>
                    </div>

                    <Link 
                      href={`/blog/${post.id}`}
                      className="block mt-4 text-green-600 hover:text-green-700 font-medium cursor-pointer"
                    >
                      Đọc tiếp →
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </div>

      <Footer />
      <Chatbot />
    </div>
  );
}
