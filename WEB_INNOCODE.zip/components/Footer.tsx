
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-pacifico text-green-400 mb-4">
              CommunityServe
            </div>
            <p className="text-gray-300 mb-4">
              Phụng sự xã hội - Serve the Community
            </p>
            <p className="text-gray-300 text-sm">
              Hỗ trợ cộng đồng nông thôn, ứng phó thiên tai và bảo vệ môi trường
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Dịch vụ</h3>
            <ul className="space-y-2">
              <li><Link href="/weather" className="text-gray-300 hover:text-green-400 cursor-pointer">Thời tiết</Link></li>
              <li><Link href="/sos" className="text-gray-300 hover:text-green-400 cursor-pointer">Cứu hộ SOS</Link></li>
              <li><Link href="/plants" className="text-gray-300 hover:text-green-400 cursor-pointer">Tư vấn cây trồng</Link></li>
              <li><Link href="/shop" className="text-gray-300 hover:text-green-400 cursor-pointer">Cửa hàng</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Cộng đồng</h3>
            <ul className="space-y-2">
              <li><Link href="/marketplace" className="text-gray-300 hover:text-green-400 cursor-pointer">Chợ tái chế</Link></li>
              <li><Link href="/blog" className="text-gray-300 hover:text-green-400 cursor-pointer">Blog</Link></li>
              <li><Link href="/about" className="text-gray-300 hover:text-green-400 cursor-pointer">Về chúng tôi</Link></li>
              <li><Link href="/contact" className="text-gray-300 hover:text-green-400 cursor-pointer">Liên hệ</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Liên hệ</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <i className="ri-phone-line text-green-400"></i>
                <span className="text-gray-300">1900 1234</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="ri-mail-line text-green-400"></i>
                <span className="text-gray-300">support@communityserve.vn</span>
              </div>
              <div className="flex space-x-4 mt-4">
                <div className="w-8 h-8 flex items-center justify-center bg-green-600 rounded-full cursor-pointer hover:bg-green-700">
                  <i className="ri-facebook-fill"></i>
                </div>
                <div className="w-8 h-8 flex items-center justify-center bg-green-600 rounded-full cursor-pointer hover:bg-green-700">
                  <i className="ri-twitter-fill"></i>
                </div>
                <div className="w-8 h-8 flex items-center justify-center bg-green-600 rounded-full cursor-pointer hover:bg-green-700">
                  <i className="ri-youtube-fill"></i>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-300">
            © 2024 CommunityServe. Tất cả quyền được bảo lưu.
          </p>
        </div>
      </div>
    </footer>
  );
}
