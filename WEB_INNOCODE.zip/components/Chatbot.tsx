
'use client';

import { useState } from 'react';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Xin chào! Tôi là AI Assistant của CommunityServe. Tôi có thể giúp bạn về thời tiết, cây trồng, thiên tai. Bạn cần hỗ trợ gì?',
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');

  const botResponses = {
    'thời tiết': 'Để xem thông tin thời tiết chi tiết, bạn có thể truy cập trang Thời tiết. Tôi có thể cung cấp dự báo 7 ngày và cảnh báo thiên tai.',
    'cây trồng': 'Tôi có thể tư vấn về cây trồng phù hợp với từng vùng miền. Bạn ở khu vực nào để tôi gợi ý cây trồng phù hợp?',
    'thiên tai': 'Về thiên tai, tôi có thể cảnh báo sớm về bão, lũ lụt, hạn hán. Bạn cần thông tin gì cụ thể?',
    'sos': 'Trong trường hợp khẩn cấp, hãy sử dụng tính năng SOS để gửi thông tin vị trí và tình trạng của bạn.',
    'default': 'Tôi hiểu bạn đang cần hỗ trợ. Bạn có thể hỏi tôi về thời tiết, cây trồng, thiên tai, hoặc các tính năng khác của website.'
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    setTimeout(() => {
      const lowerInput = inputText.toLowerCase();
      let botResponse = botResponses.default;

      for (const [key, response] of Object.entries(botResponses)) {
        if (key !== 'default' && lowerInput.includes(key)) {
          botResponse = response;
          break;
        }
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: botResponse,
        isBot: true,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botMessage]);
    }, 1000);

    setInputText('');
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div className="bg-white rounded-lg shadow-2xl w-80 h-96 mb-4 flex flex-col">
          <div className="bg-green-600 text-white p-4 rounded-t-lg flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 flex items-center justify-center bg-green-700 rounded-full">
                <i className="ri-robot-line"></i>
              </div>
              <span className="font-semibold">AI Assistant</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="w-6 h-6 flex items-center justify-center hover:bg-green-700 rounded cursor-pointer"
            >
              <i className="ri-close-line"></i>
            </button>
          </div>

          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-xs p-3 rounded-lg ${
                    message.isBot
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-green-600 text-white'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 border-t">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Nhập câu hỏi..."
                className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
              />
              <button
                onClick={handleSendMessage}
                className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-send-plane-line"></i>
              </button>
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-green-600 text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:bg-green-700 transition-all duration-300 cursor-pointer"
      >
        <i className={`ri-${isOpen ? 'close' : 'chat-1'}-line text-xl`}></i>
      </button>
    </div>
  );
}
